<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Http\Controllers\Api\Concerns\SendsExports;
use App\Http\Controllers\Controller;
use App\Http\Middleware\Authenticate;
use App\Models\Product;
use App\Models\ProductImplementationTemplate;
use App\Models\ProductImplementationTemplateTask;
use App\Services\Audit;
use App\Services\Authority;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Product/Service Catalog. Mirrors backend/app/routers/catalog.py --
 * see App\Models\Product for field rationale. Backs Sales Quotation
 * lines (not yet converted -- see docs/php-conversion-plan.md).
 */
class ProductController extends Controller
{
    use SendsExports;

    /** @var array<int, string> */
    private const EXPORT_FIELDS = [
        'name', 'product_type', 'internal_reference', 'product_category', 'tags',
        'sales_price_sgd', 'cost_sgd', 'unit_of_measure', 'tax_code', 'is_active',
    ];

    // Gated by "sales", not "company_individual_management" -- matches
    // the Python router's MODULE constant exactly.
    private const MODULE = 'sales';

    // Fields the Python router's update_product actually applies. Note
    // `is_stock` is in ProductUpdate's Pydantic schema but NOT in that
    // loop's field tuple -- i.e. the Python API accepts it in the
    // request body but silently ignores it on update (only settable at
    // create). That looks like an oversight in the Python source
    // rather than a confirmed rule, but this is a straight conversion,
    // not a bug-fix pass -- see docs/php-conversion-plan.md's
    // Conventions section ("faithful conversion, not silent fixes").
    // Flagging it here rather than changing behaviour on our own
    // judgement.
    private const UPDATABLE_FIELDS = [
        'product_type', 'name', 'internal_reference', 'product_category', 'tags',
        'sales_price_sgd', 'cost_sgd', 'unit_of_measure', 'tax_code',
        'default_reference_code_id', 'is_active',
    ];

    private function productOrFail(string $companyId, string $productId): Product
    {
        $product = Product::find($productId);
        if (! $product || $product->company_id !== $companyId) {
            throw new ApiException(404, 'Catalog item not found');
        }

        return $product;
    }

    /** Casts the money fields to float for the JSON boundary -- see App\Models\Product's cast comment. */
    private function present(Product $product): array
    {
        $data = $product->toArray();
        $data['sales_price_sgd'] = (float) $product->sales_price_sgd;
        $data['cost_sgd'] = $product->cost_sgd !== null ? (float) $product->cost_sgd : null;

        return $data;
    }

    public function index(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return $this->filtered($user->company_id, $request)->map(fn ($p) => $this->present($p))->values();
    }

    /**
     * The list the screen shows, honouring its filter -- shared with
     * the exports so an Export button always returns what is on
     * screen.
     *
     * @return Collection<int, Product>
     */
    private function filtered(string $companyId, Request $request)
    {
        $query = Product::where('company_id', $companyId);
        if (! $request->boolean('include_inactive')) {
            $query->where('is_active', true);
        }

        return $query->orderBy('name')->get();
    }

    /** @return array<int, array<string, mixed>> */
    private function exportRows(string $companyId, Request $request): array
    {
        return $this->filtered($companyId, $request)->map(fn (Product $p) => [
            'name' => $p->name,
            'product_type' => $p->product_type,
            'internal_reference' => $p->internal_reference ?? '',
            'product_category' => $p->product_category ?? '',
            'tags' => $p->tags ?? '',
            'sales_price_sgd' => number_format((float) $p->sales_price_sgd, 2, '.', ''),
            'cost_sgd' => $p->cost_sgd === null ? '' : number_format((float) $p->cost_sgd, 2, '.', ''),
            'unit_of_measure' => $p->unit_of_measure ?? '',
            'tax_code' => $p->tax_code,
            'is_active' => $p->is_active,
        ])->all();
    }

    public function exportCsv(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return $this->csvResponse(
            self::EXPORT_FIELDS, $this->exportRows($user->company_id, $request), 'catalog.csv'
        );
    }

    public function exportExcel(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return $this->xlsxResponse(
            self::EXPORT_FIELDS, $this->exportRows($user->company_id, $request), 'Catalog', 'catalog.xlsx'
        );
    }

    public function store(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'edit');

        $data = $request->validate([
            'product_type' => 'sometimes|in:service,product',
            'name' => 'required|string',
            'internal_reference' => 'sometimes|nullable|string',
            'product_category' => 'sometimes|nullable|string',
            'tags' => 'sometimes|nullable|string',
            'sales_price_sgd' => 'sometimes|numeric|min:0',
            'cost_sgd' => 'sometimes|nullable|numeric|min:0',
            'unit_of_measure' => 'sometimes|nullable|string',
            'tax_code' => 'sometimes|string',
            'default_reference_code_id' => 'sometimes|nullable|uuid',
            'is_stock' => 'sometimes|boolean',
        ]);
        $data['product_type'] ??= Product::TYPE_SERVICE;
        $data['sales_price_sgd'] ??= 0;
        $data['tax_code'] ??= 'SR'; // DEFAULT_TAX_CODE, backend/app/models/tax.py

        $product = Product::create(array_merge($data, ['company_id' => $user->company_id]));

        Audit::record(
            'product', $product->id, 'created', $user->id,
            details: "name={$data['name']}",
            newValue: ['name' => $data['name'], 'sales_price_sgd' => $data['sales_price_sgd']],
        );

        return response()->json($this->present($product->fresh()));
    }

    public function update(Request $request, string $productId)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'edit');

        $product = $this->productOrFail($user->company_id, $productId);
        $fields = $request->validate([
            'product_type' => 'sometimes|in:service,product',
            'name' => 'sometimes|string',
            'internal_reference' => 'sometimes|nullable|string',
            'product_category' => 'sometimes|nullable|string',
            'tags' => 'sometimes|nullable|string',
            'sales_price_sgd' => 'sometimes|numeric|min:0',
            'cost_sgd' => 'sometimes|nullable|numeric|min:0',
            'unit_of_measure' => 'sometimes|nullable|string',
            'tax_code' => 'sometimes|string',
            'default_reference_code_id' => 'sometimes|nullable|uuid',
            'is_stock' => 'sometimes|boolean',
            'is_active' => 'sometimes|boolean',
        ]);

        $oldValue = [];
        $newValue = [];
        foreach (self::UPDATABLE_FIELDS as $field) {
            if (! array_key_exists($field, $fields)) {
                continue;
            }
            $old = $product->{$field};
            $new = $fields[$field];
            // Compare as strings for the decimal-cast money fields so
            // "300.00" == "300.0" doesn't register as a change.
            $changed = in_array($field, ['sales_price_sgd', 'cost_sgd'], true)
                ? (float) $old !== (float) $new
                : $old !== $new;
            if (! $changed) {
                continue;
            }
            $oldValue[$field] = $old;
            $newValue[$field] = $new;
            $product->{$field} = $new;
        }

        Audit::record('product', $product->id, 'updated', $user->id, oldValue: $oldValue ?: null, newValue: $newValue ?: null);
        $product->save();

        return response()->json($this->present($product->fresh()));
    }

    // ---- Job Implementation Template ---------------------------------
    // NEW FEATURE (not a Python->PHP conversion -- see
    // docs/backlog.md / docs/planned-work.md): "Product - To add in
    // Job Implementation Template". A reusable, ordered task checklist
    // attached to a product; selecting the product on a Job Order
    // copies these tasks onto it -- see
    // App\Services\JobOrderImplementationTaskService.

    private function presentTask(ProductImplementationTemplateTask $task): array
    {
        return [
            'id' => $task->id,
            'task_name' => $task->task_name,
            'description' => $task->description,
            'sort_order' => $task->sort_order,
        ];
    }

    public function getImplementationTemplate(Request $request, string $productId)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        $product = $this->productOrFail($user->company_id, $productId);
        $template = ProductImplementationTemplate::with('tasks')->where('product_id', $product->id)->first();

        return response()->json([
            'product_id' => $product->id,
            'tasks' => $template ? $template->tasks->map(fn ($t) => $this->presentTask($t))->values() : [],
        ]);
    }

    /**
     * Replaces the whole ordered task list -- same "replace wholesale"
     * pattern as App\Http\Controllers\Api\ContractController::update()'s
     * product_ids handling, simpler than a line-by-line diff for a
     * short checklist that's edited as a whole in one form.
     */
    public function setImplementationTemplate(Request $request, string $productId)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'edit');

        $product = $this->productOrFail($user->company_id, $productId);
        $data = $request->validate([
            'tasks' => 'required|array',
            'tasks.*.task_name' => 'required|string|max:200',
            'tasks.*.description' => 'sometimes|nullable|string',
        ]);

        $template = DB::transaction(function () use ($product, $data, $user) {
            $template = ProductImplementationTemplate::firstOrCreate(
                ['product_id' => $product->id],
                ['company_id' => $product->company_id],
            );
            $oldCount = $template->tasks()->count();
            ProductImplementationTemplateTask::where('template_id', $template->id)->delete();
            foreach (array_values($data['tasks']) as $i => $task) {
                ProductImplementationTemplateTask::create([
                    'template_id' => $template->id,
                    'task_name' => $task['task_name'],
                    'description' => $task['description'] ?? null,
                    'sort_order' => $i,
                ]);
            }

            Audit::record(
                'product_implementation_template', $template->id, 'updated', $user->id,
                details: "{$product->name}: {$oldCount} -> ".count($data['tasks']).' tasks',
                oldValue: ['task_count' => $oldCount],
                newValue: ['task_count' => count($data['tasks'])],
            );

            return $template;
        });

        return response()->json([
            'product_id' => $product->id,
            'tasks' => $template->fresh('tasks')->tasks->map(fn ($t) => $this->presentTask($t))->values(),
        ]);
    }
}
