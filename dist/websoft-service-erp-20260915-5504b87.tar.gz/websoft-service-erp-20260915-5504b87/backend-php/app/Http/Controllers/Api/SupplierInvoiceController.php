<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\ApiException;
use App\Exceptions\PayablesRuleViolation;
use App\Exceptions\PostingError;
use App\Http\Controllers\Api\Concerns\SendsExports;
use App\Http\Controllers\Controller;
use App\Http\Middleware\Authenticate;
use App\Models\CompanyIndividual;
use App\Models\SupplierInvoice;
use App\Services\Audit;
use App\Services\Authority;
use App\Services\Numbering;
use App\Services\PayablesService;
use App\Services\Posting;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Supplier invoices (bills). Mirrors the bill half of
 * backend/app/routers/payables.py -- see App\Services\PayablesService
 * for the PUR-002/003 business logic this only orchestrates.
 *
 * NOT yet converted: CSV/Excel export.
 */
class SupplierInvoiceController extends Controller
{
    use SendsExports;

    /** @var array<int, string> */
    private const EXPORT_FIELDS = [
        'bill_number', 'supplier_invoice_no', 'supplier_name', 'invoice_date', 'due_date',
        'description', 'amount_sgd', 'gst_amount_sgd', 'total_amount_sgd', 'amount_paid_sgd',
        'outstanding_sgd', 'match_status', 'status',
    ];

    private const MODULE = 'accounts_payable';

    private function supplierOrFail(string $companyId, string $supplierId): CompanyIndividual
    {
        $supplier = CompanyIndividual::find($supplierId);
        if (! $supplier || $supplier->company_id !== $companyId || ! $supplier->is_supplier) {
            throw new ApiException(404, "Supplier not found -- check it exists and is marked 'Is Supplier' on the Company/Individual page.");
        }

        return $supplier;
    }

    private function billOrFail(string $companyId, string $billId): SupplierInvoice
    {
        $bill = SupplierInvoice::find($billId);
        if (! $bill || $bill->company_id !== $companyId) {
            throw new ApiException(404, 'Supplier invoice not found');
        }

        return $bill;
    }

    public function present(SupplierInvoice $bill): array
    {
        $glEntry = Posting::liveEntryFor(Posting::SOURCE_SUPPLIER_INVOICE, $bill->id);

        return [
            'id' => $bill->id,
            'bill_number' => $bill->bill_number,
            'supplier_invoice_no' => $bill->supplier_invoice_no,
            'supplier_id' => $bill->supplier_id,
            'purchase_order_id' => $bill->purchase_order_id,
            'invoice_date' => optional($bill->invoice_date)->toDateString(),
            'due_date' => optional($bill->due_date)->toDateString(),
            'description' => $bill->description,
            'amount_sgd' => (float) $bill->amount_sgd,
            'gst_amount_sgd' => (float) $bill->gst_amount_sgd,
            'total_amount_sgd' => (float) $bill->total_amount_sgd,
            'amount_paid_sgd' => (float) $bill->amount_paid_sgd,
            'outstanding_sgd' => $bill->outstandingSgd()->toFloat(),
            'match_status' => $bill->match_status,
            'match_note' => $bill->match_note,
            'status' => $bill->status,
            'gl_status' => $glEntry ? 'posted' : 'not_posted',
            'gl_voucher_number' => $glEntry?->voucher_number,
        ];
    }

    public function index(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return $this->filtered($user->company_id, $request)
            ->map(fn (SupplierInvoice $b) => $this->present($b))->values();
    }

    /**
     * The list the screen shows, honouring its filters -- shared with
     * the exports so an Export button always returns what is on
     * screen.
     *
     * @return Collection<int, SupplierInvoice>
     */
    private function filtered(string $companyId, Request $request)
    {
        $query = SupplierInvoice::where('company_id', $companyId);
        foreach (['supplier_id', 'status'] as $field) {
            if ($request->filled($field)) {
                $query->where($field, $request->query($field));
            }
        }

        return $query->orderByDesc('invoice_date')->get();
    }

    /** @return array<int, array<string, mixed>> */
    private function exportRows(string $companyId, Request $request): array
    {
        $supplierNames = CompanyIndividual::where('company_id', $companyId)->pluck('name', 'id');

        return $this->filtered($companyId, $request)->map(fn (SupplierInvoice $b) => [
            'bill_number' => $b->bill_number,
            'supplier_invoice_no' => $b->supplier_invoice_no ?? '',
            'supplier_name' => $supplierNames[$b->supplier_id] ?? '',
            'invoice_date' => optional($b->invoice_date)->toDateString(),
            'due_date' => optional($b->due_date)->toDateString() ?? '',
            'description' => $b->description,
            'amount_sgd' => number_format((float) $b->amount_sgd, 2, '.', ''),
            'gst_amount_sgd' => number_format((float) $b->gst_amount_sgd, 2, '.', ''),
            'total_amount_sgd' => number_format((float) $b->total_amount_sgd, 2, '.', ''),
            'amount_paid_sgd' => number_format((float) $b->amount_paid_sgd, 2, '.', ''),
            'outstanding_sgd' => $b->outstandingSgd()->toString(),
            'match_status' => $b->match_status,
            'status' => $b->status,
        ])->all();
    }

    public function exportCsv(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return $this->csvResponse(
            self::EXPORT_FIELDS, $this->exportRows($user->company_id, $request), 'supplier-bills.csv'
        );
    }

    public function exportExcel(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return $this->xlsxResponse(
            self::EXPORT_FIELDS, $this->exportRows($user->company_id, $request),
            'Supplier Bills', 'supplier-bills.xlsx'
        );
    }

    public function show(Request $request, string $billId)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'view');

        return response()->json($this->present($this->billOrFail($user->company_id, $billId)));
    }

    /**
     * Enter a supplier invoice. It is 2-way matched against its PO
     * immediately (PUR-002); a match auto-approves it for payment
     * (PUR-003), a mismatch becomes an exception.
     */
    public function store(Request $request)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'edit');

        $data = $request->validate([
            'supplier_id' => 'required|uuid',
            'purchase_order_id' => 'sometimes|nullable|uuid',
            'supplier_invoice_no' => 'sometimes|nullable|string',
            'invoice_date' => 'required|date',
            'description' => 'required|string|min:1',
            'amount_sgd' => 'required|numeric|gt:0',
            'gst_amount_sgd' => 'sometimes|numeric|min:0',
        ]);
        $this->supplierOrFail($user->company_id, $data['supplier_id']);

        try {
            $bill = DB::transaction(function () use ($user, $data) {
                $net = (float) $data['amount_sgd'];
                $gst = (float) ($data['gst_amount_sgd'] ?? 0);

                $bill = SupplierInvoice::create([
                    'company_id' => $user->company_id,
                    'supplier_id' => $data['supplier_id'],
                    'purchase_order_id' => $data['purchase_order_id'] ?? null,
                    'bill_number' => Numbering::next($user->company_id, 'supplier_invoice'),
                    'supplier_invoice_no' => $data['supplier_invoice_no'] ?? null,
                    'invoice_date' => $data['invoice_date'],
                    'due_date' => PayablesService::dueDateForBill($data['supplier_id'], Carbon::parse($data['invoice_date']))?->toDateString(),
                    'description' => $data['description'],
                    'amount_sgd' => $net,
                    'gst_amount_sgd' => $gst,
                    'total_amount_sgd' => $net + $gst,
                ]);

                PayablesService::matchBillToPo($bill, $user->id);

                Audit::record(
                    entityType: 'supplier_invoice',
                    entityId: $bill->id,
                    action: 'received',
                    actorUserId: $user->id,
                    details: "{$bill->bill_number}: {$bill->match_note}",
                    newValue: [
                        'bill_number' => $bill->bill_number,
                        'total_sgd' => (string) $bill->total_amount_sgd,
                        'match_status' => $bill->match_status,
                        'status' => $bill->status,
                    ],
                );

                return $bill;
            });
        } catch (PayablesRuleViolation $e) {
            throw new ApiException(422, $e->getMessage());
        }

        return response()->json($this->present($bill->fresh()));
    }

    /** ACC-004: UNGL -- reverse this bill's GL posting. */
    public function ungl(Request $request, string $billId)
    {
        $user = Authenticate::user($request);
        Authority::requireModuleAccess($user, self::MODULE, 'edit');

        $bill = $this->billOrFail($user->company_id, $billId);
        $data = $request->validate(['reason' => 'required|string|min:1']);

        try {
            $reversal = Posting::unpost(Posting::SOURCE_SUPPLIER_INVOICE, $bill->id, $user->id, $data['reason'], 'supplier_invoice');
        } catch (PostingError $e) {
            throw new ApiException(422, $e->getMessage());
        }

        return response()->json(['status' => 'reversed', 'reversal_voucher' => $reversal->voucher_number]);
    }
}
